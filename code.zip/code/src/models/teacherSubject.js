export default class teacherSubject {
    constructor(id,fullname,sub){
        this.id = id
        this.fullname = fullname
        this.sub = sub
    }
}