export default class signUp {
    constructor(id,username,password,fullname,birthDate,email,mobile,gender,address,roleId){
        this.id = id
        this.username = username
        this.password = password
        this.fullname = fullname
        this.birthDate = birthDate
        this.email = email
        this.mobile = mobile
        this.gender = gender
        this.address = address
        this.roleId = roleId
    }
}