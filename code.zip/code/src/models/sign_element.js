export default class signElement {
    constructor(id,user_name,city){
        this.id = id
        this.user_name = user_name
        this.city = city
    }
}