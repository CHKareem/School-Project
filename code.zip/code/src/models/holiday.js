export default class holiday {
    constructor(id,name,date,description){
        this.id = id
        this.name = name
        this.date = date
        this.description = description
    }
}