export default class SClass {
    constructor(id,name,adminUserId,containsOptionalSubjects){
        this.id = id
        this.name = name
        this.adminUserId = adminUserId
        this.containsOptionalSubjects = containsOptionalSubjects
    }
}